import express from 'express';
import path from 'path';
import UserController from "./src/controllers/user.controller.js";
import JobController from "./src/controllers/job.controller.js";
import ejsLayouts from 'express-ejs-layouts'
import session from 'express-session';
import applicants from "./src/controllers/applicants.controller.js";
import check from './src/middleware/auth.js';
import { uploadFile } from './src/middleware/file.js';
const app = express();
const userController = new UserController();
const jobController = new JobController();
const applicant = new applicants();
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } 
  }));
app.set('view engine', 'ejs');
app.set("views", path.join(path.resolve(),"src", "views"));
app.use(ejsLayouts);
app.use(express.urlencoded({ extended: true }));


// Auth Routes
app.get('/', userController.load);
app.get('/register', userController.getR);
app.post('/register', userController.postR);
app.get('/login', userController.getL);
app.post('/login', userController.postL);
app.post('/logout', userController.logout);
app.get('/err', userController.error);


// Job Routes

app.get('/jobs', jobController.showCard);
app.get('/getDetail/:id', jobController.details);
app.get('/addjob', check, jobController.addjob);
app.post('/addjob', check,  jobController.newjob);
app.get('/delete/:id', check, jobController.deletejob);
app.get('/update/:id', check, jobController.getupdatejob);
app.post('/update', check, jobController.postupdatejob);

app.get('/apply/:id', applicant.getapply);
app.post('/apply',uploadFile.single('resume'), applicant.postapply);


app.use(express.static('src/views'));
app.listen(3000, () => console.log('Listening on port 3000'));
