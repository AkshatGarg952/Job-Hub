export default function check(req, res, next){
    if(req.session.user){
        next();
    }
    else{
        const username  = req.session.user;
        res.render("login", {user:username, layout:'layouts/layout'});
    }
}