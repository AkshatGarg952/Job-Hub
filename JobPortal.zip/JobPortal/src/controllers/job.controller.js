import jobClass from "../models/job.model.js";

export default class JobController{
showCard(req, res){
    const jobs = jobClass.get();
    const username = req.session.user;
    res.render("jobcard", {jobs:jobs, user:username, layout:'layouts/layout'});
}

addjob(req, res) {
    res.render("NewJob",{layout:'layouts/layout2'});
}

newjob(req,res){
    jobClass.add(req.body.category, req.body.designation, req.body.location, req.body.company, req.body.salary, req.body.positions, req.body.skills, req.body.deadline);
    const jobs = jobClass.get();
    const username = req.session.user;
    res.render("jobcard", {user:username, jobs:jobs, layout:'layouts/layout'});
}

details(req, res){
   const id = req.params.id;
   const  job = jobClass.getById(id);
   const username = req.session.user;
   res.render("jobdetail", {user:username, job:job, layout:'layouts/layout'})
}



deletejob(req, res){
    const id = req.params.id;
    const jobFound = jobClass.getById(id);
    if (!jobFound) {
          return res
            .status(401)
            .send('Job not found');
        }
        jobClass.delete(id);
        const jobs = jobClass.get();
        const username = req.session.user;
        res.render("jobcard", {user:username, jobs:jobs, layout:'layouts/layout'});
}

getupdatejob(req, res){
   const id = req.params.id;
   const  job = jobClass.getById(id);
   res.render("update", {Job:job, layout:'layouts/layout2'})

}

postupdatejob(req, res){
    jobClass.update(req.body);
    console.log(req.body);
    const jobs = jobClass.get();
    const username = req.session.user;
    res.render("jobcard", {user:username, jobs:jobs,layout:'layouts/layout'})
}

}
