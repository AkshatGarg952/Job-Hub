import UserModel from "../models/user.model.js";

export default class UserController{

    load(req,res){
      const username  = req.session.user;
        res.render("homepage", {user:username, layout:'layouts/layout'});
    }

    getR(req,res){
      const username  = req.session.user;
        res.render("register", {user:username, layout:'layouts/layout'});
    }

    getL(req,res){
      const username  = req.session.user;
        res.render("login", {user:username, layout:'layouts/layout'});
    }

    postL(req,res){
     const boolean = UserModel.isValid(req.body.email, req.body.password);
     if(boolean){
      const username = UserModel.getUsername(req.body.email, req.body.password);
      req.session.user = username;
        res.redirect("/");
     }
     else{
        res.redirect("/err");
     }
    }

    postR(req, res){
      UserModel.add(req.body.name, req.body.email, req.body.password);
      res.redirect("/login");
    }

    logout(req, res) {
        req.session.destroy((err) => {
          if (err) {
            console.log(err);
          } else {
            res.redirect('/login');
          }
        });
      }

      error(req, res){
        const username  = req.session.user;
        res.render('oops1', {user:username, layout:'layouts/layout'});
      }


}