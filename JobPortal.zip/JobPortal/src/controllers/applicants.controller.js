import nodemailer from 'nodemailer';
import jobClass from "../models/job.model.js";
export default class applicants{

    getapply(req, res){
        const username  = req.session.user;
        res.render("apply", {user:username, layout:'layouts/layout', id:req.params.id});
    }

    postapply(req, res){

        const transporter = nodemailer.createTransport({
            service: 'Gmail',
            auth: {
            user: 'gargakshat55555@gmail.com',
            pass: 'bryo nfuk dije nclq',
            },
            });

            const mailOptions = {
                from: 'gargakshat55555@gmail.com',
                to: req.body.email,
                subject: 'Job Application Confirmation',
                text:"Dear User,Thank you for applying to a job at Easily. We have received your application and are currently reviewing it.If your qualifications match our requirements, we will contact you for the next steps of the selection process.Thank you for your interest in joining our team!Best regards",
                
            
    }

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Error occurred:', error);
            }

            else {
                console.log('Email sent:', info.response);
                }
                
            });


            const id = req.body.id;
            const  job = jobClass.getById(id);
            job.applicants+=1;
            const username = req.session.user;
            res.render("jobdetail", {user:username, job:job, layout:'layouts/layout'})

}


}