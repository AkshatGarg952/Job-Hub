export default class jobClass{
    constructor(category, designation, location, company, salary, position, skills, deadline){
        this.id = jobs.length+1;
        this.category = category;
        this.designation = designation;
        this.location = location;
        this.company = company;
        this.salary = salary;
        this.positions = position;
        this.skills = skills;
        this.deadline = deadline;
        this.applicants = 0;
    }

    static add(category, designation, location, company, salary, position, skills, deadline){
    const newJob = new jobClass(category, designation, location, company, salary, position, skills, deadline);
    jobs.push(newJob);
    }

    static get(){
        return jobs;
    }

    static getById(id) {
        return jobs.find((p) => p.id == id);
      }

      static delete(id) {
        const index = jobs.findIndex(
          (p) => p.id == id
        );
        jobs.splice(index, 1);
      }

      static update(jobObj){
        const index = jobs.findIndex(
            (p) => p.id == jobObj.id
          );
          jobs[index] = jobObj;
      }
}

const jobs = [
    {
        id:1,
    category:"Tech",
    location:"Gurgaon HR IND Remote",
    designation:"SDE",
    company:"Coding Ninjas",
    salary:"4-20lpa",
    positions:5,
    applicants:2,
    skills:["REACT",'NODEJS','JS','SQL','MONGODB','EXPRESS','AWS'],
    deadline:"30 Aug 2023"
},

{
    id:2,
    category:"Tech",
    location:"Bangalore IND",
    designation:"SDE",
    company:"Juspay",
    salary:"20-26lpa",
    positions:3,
    applicants:0,
    skills:["REACT",'NODEJS','JS','SQL','MONGODB','EXPRESS','AWS'],
    deadline:"30 Aug 2023"
},

{
    id:3,
    category:"Tech",
    location:"Pune IND On-Site",
    designation:"Angular Developer",
    company:"Go Digit",
    salary:"6-10lpa",
    positions:7,
    applicants:0,
    skills:["ANGULAR",'NODEJS','JS','SQL','MONGODB','EXPRESS','AWS'],
    deadline:"30 Aug 2023"
}

];