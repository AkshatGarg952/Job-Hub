export default class UserModel{
    constructor(name, email, pass){
     this.name = name;
     this.email = email;
     this.pass = pass;
    }

    static add(name, email, pass){
      let user = new UserModel(name,email,pass);
      users.push(user);
    }

    static isValid(email, pass){
        const result = users.find(
            (u) =>
              u.email == email && u.pass == pass
          );
          return result;
        }

        static getUsername(email, pass){
          const user = users.find(user => user.email === email && user.pass === pass);
          if(user){
            return user.name;
          }
          else{
            return false;
          }
        }
    }


let users = [];